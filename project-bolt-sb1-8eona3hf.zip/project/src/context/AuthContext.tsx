import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  switchRole: (role: 'shipper' | 'fleet_admin' | 'admin') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo purposes
const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Shipper',
    email: 'shipper@logx.com',
    phone: '+234 800 123 4567',
    role: 'shipper'
  },
  {
    id: '2',
    name: 'Sarah Fleet Manager',
    email: 'admin@logx.com',
    phone: '+234 800 987 6543',
    role: 'fleet_admin'
  },
  {
    id: '3',
    name: 'Admin User',
    email: 'superadmin@logx.com',
    phone: '+234 800 555 0000',
    role: 'admin' as any
  }
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(mockUsers[0]); // Default to shipper for demo

  const login = async (email: string, password: string): Promise<boolean> => {
    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const switchRole = (role: 'shipper' | 'fleet_admin' | 'admin') => {
    const roleUser = mockUsers.find(u => u.role === role);
    if (roleUser) {
      setUser(roleUser);
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, switchRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}