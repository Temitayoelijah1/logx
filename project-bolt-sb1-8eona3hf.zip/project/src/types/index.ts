export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'shipper' | 'fleet_admin' | 'admin';
}

export interface Vehicle {
  id: string;
  plateNumber: string;
  type: 'truck' | 'van' | 'pickup';
  status: 'available' | 'in_transit' | 'maintenance' | 'offline';
  driverId?: string;
  currentLocation?: {
    lat: number;
    lng: number;
    address: string;
  };
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  licenseNumber: string;
  vehicleId?: string;
  status: 'active' | 'offline' | 'on_trip';
  rating: number;
  currentLocation?: {
    lat: number;
    lng: number;
  };
}

export interface Booking {
  id: string;
  trackingId: string;
  shipperId: string;
  pickupLocation: {
    address: string;
    coordinates: { lat: number; lng: number };
  };
  dropoffLocation: {
    address: string;
    coordinates: { lat: number; lng: number };
  };
  loadType: string;
  scheduledDate: string;
  status: 'pending' | 'assigned' | 'in_transit' | 'delivered' | 'cancelled';
  bookingMode: 'online' | 'offline';
  assignedVehicleId?: string;
  assignedDriverId?: string;
  createdAt: string;
  estimatedDelivery?: string;
  price: number;
}

export interface Trip {
  id: string;
  bookingId: string;
  vehicleId: string;
  driverId: string;
  status: 'active' | 'completed' | 'cancelled';
  startTime: string;
  endTime?: string;
  currentLocation?: {
    lat: number;
    lng: number;
    timestamp: string;
  };
  route: {
    lat: number;
    lng: number;
    timestamp: string;
  }[];
}