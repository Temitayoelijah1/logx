import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, ArrowLeft, ChevronRight } from 'lucide-react';

interface PageNavigationProps {
  title?: string;
  subtitle?: string;
  showBreadcrumb?: boolean;
  customBackPath?: string;
  className?: string;
}

export default function PageNavigation({ 
  title, 
  subtitle, 
  showBreadcrumb = true,
  customBackPath,
  className = ""
}: PageNavigationProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleBack = () => {
    if (customBackPath) {
      navigate(customBackPath);
    } else if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  const handleHome = () => {
    navigate('/');
  };

  // Generate breadcrumb from current path
  const generateBreadcrumb = () => {
    const pathSegments = location.pathname.split('/').filter(segment => segment);
    const breadcrumbItems = [{ label: 'Home', path: '/' }];

    let currentPath = '';
    pathSegments.forEach((segment, index) => {
      currentPath += `/${segment}`;
      let label = segment.charAt(0).toUpperCase() + segment.slice(1);
      
      // Custom labels for specific routes
      const customLabels: Record<string, string> = {
        'dashboard': 'Dashboard',
        'admin': 'Admin Panel',
        'book': 'Book Truck',
        'track': 'Track Shipment',
        'login': 'Login',
        'signup': 'Sign Up',
        'vehicles': 'Manage Vehicles',
        'drivers': 'Manage Drivers',
        'assign-trips': 'Assign Trips',
        'tracking': 'Fleet Tracking',
        'analytics': 'Analytics',
        'users': 'User Management',
        'fleets': 'Fleet Companies',
        'trips': 'Trip Oversight'
      };

      if (customLabels[segment]) {
        label = customLabels[segment];
      }

      breadcrumbItems.push({ label, path: currentPath });
    });

    return breadcrumbItems;
  };

  const breadcrumbItems = showBreadcrumb ? generateBreadcrumb() : [];

  return (
    <div className={`bg-white border-b border-gray-200 ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Left side - Navigation buttons */}
          <div className="flex items-center space-x-3">
            <button
              onClick={handleBack}
              className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              title="Go back"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Back</span>
            </button>
            
            <button
              onClick={handleHome}
              className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              title="Go to home"
            >
              <Home className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Home</span>
            </button>
          </div>

          {/* Center - Page title and breadcrumb */}
          <div className="flex-1 min-w-0 mx-6">
            {showBreadcrumb && breadcrumbItems.length > 1 && (
              <nav className="flex items-center space-x-1 text-sm text-gray-500 mb-1">
                {breadcrumbItems.map((item, index) => (
                  <React.Fragment key={item.path}>
                    {index > 0 && <ChevronRight className="h-3 w-3" />}
                    <button
                      onClick={() => navigate(item.path)}
                      className={`hover:text-gray-700 transition-colors ${
                        index === breadcrumbItems.length - 1 
                          ? 'text-gray-900 font-medium' 
                          : 'hover:underline'
                      }`}
                    >
                      {item.label}
                    </button>
                  </React.Fragment>
                ))}
              </nav>
            )}
            
            {title && (
              <div>
                <h1 className="text-xl font-semibold text-gray-900 truncate">{title}</h1>
                {subtitle && (
                  <p className="text-sm text-gray-600 truncate">{subtitle}</p>
                )}
              </div>
            )}
          </div>

          {/* Right side - Additional actions space */}
          <div className="flex items-center space-x-2">
            {/* This space can be used for page-specific actions */}
          </div>
        </div>
      </div>
    </div>
  );
}