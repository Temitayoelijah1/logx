import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Truck, 
  User, 
  LogOut, 
  Settings, 
  Menu, 
  X,
  Package,
  MapPin,
  BarChart3,
  Users,
  Calendar,
  Phone,
  Mail,
  Shield
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Header() {
  const { user, logout, switchRole } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;
  const isActiveSection = (section: string) => location.pathname.startsWith(section);

  const publicNavItems = [
    { path: '/', label: 'Home', icon: null },
    { path: '/book', label: 'Book Truck', icon: Package },
    { path: '/track', label: 'Track Shipment', icon: MapPin },
  ];

  const shipperNavItems = [
    { path: '/dashboard', label: 'Dashboard', icon: BarChart3 },
    { path: '/dashboard/bookings', label: 'My Bookings', icon: Package },
    { path: '/dashboard/track', label: 'Track', icon: MapPin },
  ];

  const fleetNavItems = [
    { path: '/dashboard', label: 'Dashboard', icon: BarChart3 },
    { path: '/dashboard/vehicles', label: 'Vehicles', icon: Truck },
    { path: '/dashboard/drivers', label: 'Drivers', icon: Users },
    { path: '/dashboard/assign-trips', label: 'Assign Trips', icon: Calendar },
    { path: '/dashboard/tracking', label: 'Fleet Tracking', icon: MapPin },
    { path: '/dashboard/analytics', label: 'Analytics', icon: BarChart3 },
  ];

  const adminNavItems = [
    { path: '/admin', label: 'Admin Panel', icon: Shield },
  ];

  const getDashboardNavItems = () => {
    if (!user) return [];
    if (user.role === 'admin') return adminNavItems;
    return user.role === 'fleet_admin' ? fleetNavItems : shipperNavItems;
  };

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 flex-shrink-0" onClick={closeMobileMenu}>
            <div className="p-2 bg-blue-600 rounded-lg">
              <Truck className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">LogX</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {/* Public Navigation */}
            {publicNavItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive(item.path) 
                    ? 'text-blue-600 bg-blue-50' 
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                {item.icon && <item.icon className="h-4 w-4 mr-2" />}
                {item.label}
              </Link>
            ))}

            {/* Dashboard Navigation */}
            {user && (
              <>
                <div className="h-6 w-px bg-gray-300 mx-2" />
                {getDashboardNavItems().map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive(item.path) 
                        ? 'text-blue-600 bg-blue-50' 
                        : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                    }`}
                  >
                    <item.icon className="h-4 w-4 mr-2" />
                    {item.label}
                  </Link>
                ))}
              </>
            )}
          </nav>

          {/* User Menu & Mobile Toggle */}
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-3">
                {/* Role Switcher for Demo */}
                <div className="hidden sm:flex space-x-1 bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => switchRole('shipper')}
                    className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                      user.role === 'shipper'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    Shipper
                  </button>
                  <button
                    onClick={() => switchRole('fleet_admin')}
                    className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                      user.role === 'fleet_admin'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    Fleet Admin
                  </button>
                  <button
                    onClick={() => switchRole('admin')}
                    className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                      user.role === 'admin'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    Admin
                  </button>
                </div>

                {/* User Info */}
                <div className="hidden md:flex items-center space-x-2">
                  <div className="p-2 bg-gray-100 rounded-full">
                    <User className="h-4 w-4 text-gray-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{user.role.replace('_', ' ')}</p>
                  </div>
                </div>

                {/* Settings & Logout */}
                <div className="hidden md:flex items-center space-x-1">
                  <button
                    className="p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-lg hover:bg-gray-50"
                    title="Settings"
                  >
                    <Settings className="h-4 w-4" />
                  </button>
                  <button
                    onClick={logout}
                    className="p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-lg hover:bg-gray-50"
                    title="Logout"
                  >
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link
                  to="/login"
                  className="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                >
                  Sign Up
                </Link>
              </div>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 bg-white">
            <div className="px-4 py-4 space-y-2">
              {/* Public Navigation */}
              <div className="space-y-1">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                  Navigation
                </div>
                {publicNavItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={closeMobileMenu}
                    className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive(item.path) 
                        ? 'text-blue-600 bg-blue-50' 
                        : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                    }`}
                  >
                    {item.icon && <item.icon className="h-4 w-4 mr-3" />}
                    {item.label}
                  </Link>
                ))}
              </div>

              {/* Dashboard Navigation */}
              {user && (
                <div className="space-y-1 pt-4 border-t border-gray-200">
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                    {user.role === 'admin' ? 'Administration' : 
                     user.role === 'fleet_admin' ? 'Fleet Management' : 'My Account'}
                  </div>
                  {getDashboardNavItems().map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={closeMobileMenu}
                      className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        isActive(item.path) 
                          ? 'text-blue-600 bg-blue-50' 
                          : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                      }`}
                    >
                      <item.icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </Link>
                  ))}
                </div>
              )}

              {/* User Actions */}
              {user ? (
                <div className="space-y-1 pt-4 border-t border-gray-200">
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                    Account
                  </div>
                  
                  {/* User Info */}
                  <div className="px-3 py-2">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-100 rounded-full">
                        <User className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{user.name}</p>
                        <p className="text-xs text-gray-500 capitalize">{user.role.replace('_', ' ')}</p>
                      </div>
                    </div>
                  </div>

                  {/* Role Switcher */}
                  <div className="px-3 py-2">
                    <div className="text-xs text-gray-500 mb-2">Switch Role (Demo)</div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          switchRole('shipper');
                          closeMobileMenu();
                        }}
                        className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                          user.role === 'shipper'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        Shipper
                      </button>
                      <button
                        onClick={() => {
                          switchRole('fleet_admin');
                          closeMobileMenu();
                        }}
                        className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                          user.role === 'fleet_admin'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        Fleet Admin
                      </button>
                      <button
                        onClick={() => {
                          switchRole('admin');
                          closeMobileMenu();
                        }}
                        className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                          user.role === 'admin'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        Admin
                      </button>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <button
                    className="flex items-center w-full px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    <Settings className="h-4 w-4 mr-3" />
                    Settings
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      closeMobileMenu();
                    }}
                    className="flex items-center w-full px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <LogOut className="h-4 w-4 mr-3" />
                    Logout
                  </button>
                </div>
              ) : (
                <div className="space-y-1 pt-4 border-t border-gray-200">
                  <Link
                    to="/login"
                    onClick={closeMobileMenu}
                    className="flex items-center w-full px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    Login
                  </Link>
                  <Link
                    to="/signup"
                    onClick={closeMobileMenu}
                    className="flex items-center w-full px-3 py-2 text-sm font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Sign Up
                  </Link>
                </div>
              )}

              {/* Contact Info */}
              <div className="space-y-1 pt-4 border-t border-gray-200">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                  Support
                </div>
                <a
                  href="tel:+2348005649"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <Phone className="h-4 w-4 mr-3" />
                  +234 800 LOGX (5649)
                </a>
                <a
                  href="mailto:support@logx.africa"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <Mail className="h-4 w-4 mr-3" />
                  support@logx.africa
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}