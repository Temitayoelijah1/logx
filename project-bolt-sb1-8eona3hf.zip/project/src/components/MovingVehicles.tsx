import React from 'react';
import { Truck, Car, Bike, Package } from 'lucide-react';

const MovingVehicles = () => {
  const vehicles = [
    { icon: Truck, name: 'Heavy Truck', color: 'text-blue-600', size: 'h-8 w-8' },
    { icon: Car, name: 'Delivery Van', color: 'text-green-600', size: 'h-7 w-7' },
    { icon: Bike, name: 'Motorcycle', color: 'text-orange-600', size: 'h-6 w-6' },
    { icon: Package, name: 'Pickup Truck', color: 'text-purple-600', size: 'h-7 w-7' },
    { icon: Truck, name: 'Container Truck', color: 'text-red-600', size: 'h-8 w-8' },
    { icon: Car, name: 'Mini Van', color: 'text-indigo-600', size: 'h-6 w-6' },
  ];

  return (
    <div className="relative bg-gradient-to-r from-blue-50 via-white to-green-50 py-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            Our Fleet Across Africa
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            From motorcycles for last-mile delivery to heavy trucks for industrial cargo - 
            we have the right vehicle for every shipment
          </p>
        </div>

        {/* Moving Vehicles Animation */}
        <div className="relative h-32 mb-8">
          {/* Road/Path Background */}
          <div className="absolute inset-0 flex items-center">
            <div className="w-full h-2 bg-gray-300 rounded-full relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-gray-300 via-gray-400 to-gray-300 animate-pulse"></div>
              {/* Road markings */}
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white transform -translate-y-1/2 opacity-60">
                <div className="flex space-x-4 animate-marquee">
                  {[...Array(20)].map((_, i) => (
                    <div key={i} className="w-8 h-0.5 bg-white"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Moving Vehicles */}
          <div className="absolute inset-0 flex items-center">
            {vehicles.map((vehicle, index) => {
              const VehicleIcon = vehicle.icon;
              const delay = index * 2; // Stagger the animations
              const duration = 15 + (index * 2); // Vary speeds
              
              return (
                <div
                  key={index}
                  className="absolute flex flex-col items-center"
                  style={{
                    animation: `moveVehicle ${duration}s linear infinite`,
                    animationDelay: `${delay}s`,
                  }}
                >
                  {/* Vehicle Icon */}
                  <div className={`p-3 bg-white rounded-full shadow-lg border-2 border-gray-100 ${vehicle.color} mb-2 transform hover:scale-110 transition-transform`}>
                    <VehicleIcon className={vehicle.size} />
                  </div>
                  
                  {/* Vehicle Label */}
                  <div className="bg-white px-2 py-1 rounded-full shadow-sm border border-gray-200">
                    <span className="text-xs font-medium text-gray-700 whitespace-nowrap">
                      {vehicle.name}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stats Banner */}
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">500+</div>
              <div className="text-sm text-gray-600">Verified Drivers</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-green-600 mb-1">1000+</div>
              <div className="text-sm text-gray-600">Active Vehicles</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">50+</div>
              <div className="text-sm text-gray-600">Cities Covered</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-purple-600 mb-1">98%</div>
              <div className="text-sm text-gray-600">On-Time Delivery</div>
            </div>
          </div>
        </div>

        {/* Vehicle Types Grid */}
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Truck className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Heavy Trucks</h3>
                <p className="text-sm text-gray-500">5-20 tons capacity</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm">
              Perfect for machinery, construction materials, and large cargo shipments across long distances.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-3 bg-green-100 rounded-lg">
                <Car className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Delivery Vans</h3>
                <p className="text-sm text-gray-500">1-3 tons capacity</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm">
              Ideal for electronics, retail goods, and medium-sized deliveries in urban areas.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-3 bg-orange-100 rounded-lg">
                <Bike className="h-8 w-8 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Motorcycles</h3>
                <p className="text-sm text-gray-500">Up to 50kg</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm">
              Fast last-mile delivery for documents, small packages, and urgent deliveries.
            </p>
          </div>
        </div>
      </div>

      {/* Background Decorative Elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-blue-100 rounded-full opacity-20 animate-float"></div>
      <div className="absolute bottom-10 right-10 w-16 h-16 bg-green-100 rounded-full opacity-20 animate-float" style={{ animationDelay: '2s' }}></div>
      <div className="absolute top-1/2 left-1/4 w-12 h-12 bg-orange-100 rounded-full opacity-20 animate-float" style={{ animationDelay: '4s' }}></div>
    </div>
  );
};

export default MovingVehicles;