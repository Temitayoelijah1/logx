import { Vehicle, Driver, Booking, Trip } from '../types';

export const mockVehicles: Vehicle[] = [
  {
    id: 'v1',
    plateNumber: 'LAG-123-AB',
    type: 'truck',
    status: 'available',
    driverId: 'd1',
    currentLocation: {
      lat: 6.5244,
      lng: 3.3792,
      address: 'Victoria Island, Lagos'
    }
  },
  {
    id: 'v2',
    plateNumber: 'ABJ-456-CD',
    type: 'van',
    status: 'in_transit',
    driverId: 'd2',
    currentLocation: {
      lat: 6.6018,
      lng: 3.3515,
      address: 'Ikeja, Lagos'
    }
  },
  {
    id: 'v3',
    plateNumber: 'KAN-789-EF',
    type: 'truck',
    status: 'maintenance',
    currentLocation: {
      lat: 6.4581,
      lng: 3.6012,
      address: 'Lekki, Lagos'
    }
  }
];

export const mockDrivers: Driver[] = [
  {
    id: 'd1',
    name: 'Emeka Johnson',
    phone: '+234 803 123 4567',
    licenseNumber: 'DL-12345678',
    vehicleId: 'v1',
    status: 'active',
    rating: 4.8,
    currentLocation: {
      lat: 6.5244,
      lng: 3.3792
    }
  },
  {
    id: 'd2',
    name: 'Fatima Abdullahi',
    phone: '+234 806 987 6543',
    licenseNumber: 'DL-87654321',
    vehicleId: 'v2',
    status: 'on_trip',
    rating: 4.9,
    currentLocation: {
      lat: 6.6018,
      lng: 3.3515
    }
  },
  {
    id: 'd3',
    name: 'Chidi Okafor',
    phone: '+234 809 555 1234',
    licenseNumber: 'DL-11223344',
    status: 'active',
    rating: 4.7
  }
];

export const mockBookings: Booking[] = [
  {
    id: 'b1',
    trackingId: 'LGX-001-2024',
    shipperId: '1',
    pickupLocation: {
      address: 'Ikeja Computer Village, Lagos',
      coordinates: { lat: 6.6018, lng: 3.3515 }
    },
    dropoffLocation: {
      address: 'Onitsha Main Market, Anambra',
      coordinates: { lat: 6.1623, lng: 6.7984 }
    },
    loadType: 'Electronics',
    scheduledDate: '2024-01-15T09:00:00Z',
    status: 'in_transit',
    bookingMode: 'online',
    assignedVehicleId: 'v2',
    assignedDriverId: 'd2',
    createdAt: '2024-01-14T10:30:00Z',
    estimatedDelivery: '2024-01-15T18:00:00Z',
    price: 45000
  },
  {
    id: 'b2',
    trackingId: 'LGX-002-2024',
    shipperId: '1',
    pickupLocation: {
      address: 'Apapa Port, Lagos',
      coordinates: { lat: 6.4264, lng: 3.3470 }
    },
    dropoffLocation: {
      address: 'Kano Industrial Area, Kano',
      coordinates: { lat: 12.0022, lng: 8.5919 }
    },
    loadType: 'Machinery',
    scheduledDate: '2024-01-16T06:00:00Z',
    status: 'pending',
    bookingMode: 'offline',
    createdAt: '2024-01-14T14:20:00Z',
    price: 120000
  }
];

export const mockTrips: Trip[] = [
  {
    id: 't1',
    bookingId: 'b1',
    vehicleId: 'v2',
    driverId: 'd2',
    status: 'active',
    startTime: '2024-01-15T09:15:00Z',
    currentLocation: {
      lat: 6.6018,
      lng: 3.3515,
      timestamp: '2024-01-15T12:30:00Z'
    },
    route: [
      { lat: 6.6018, lng: 3.3515, timestamp: '2024-01-15T09:15:00Z' },
      { lat: 6.5500, lng: 3.4000, timestamp: '2024-01-15T10:00:00Z' },
      { lat: 6.6018, lng: 3.3515, timestamp: '2024-01-15T12:30:00Z' }
    ]
  }
];