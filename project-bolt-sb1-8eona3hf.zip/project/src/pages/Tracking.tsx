import React, { useState } from 'react';
import { Search, MapPin, Clock, User, Phone, Truck, Package, Navigation } from 'lucide-react';
import { mockBookings, mockDrivers, mockVehicles } from '../data/mockData';
import PageNavigation from '../components/Navigation/PageNavigation';

export default function Tracking() {
  const [trackingId, setTrackingId] = useState('');
  const [shipment, setShipment] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      const booking = mockBookings.find(b => b.trackingId.toLowerCase() === trackingId.toLowerCase());
      if (booking) {
        const driver = mockDrivers.find(d => d.id === booking.assignedDriverId);
        const vehicle = mockVehicles.find(v => v.id === booking.assignedVehicleId);
        setShipment({ ...booking, driver, vehicle });
      } else {
        setShipment(null);
      }
      setIsLoading(false);
    }, 1000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-orange-600 bg-orange-100';
      case 'assigned': return 'text-blue-600 bg-blue-100';
      case 'in_transit': return 'text-purple-600 bg-purple-100';
      case 'delivered': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pending Assignment';
      case 'assigned': return 'Driver Assigned';
      case 'in_transit': return 'In Transit';
      case 'delivered': return 'Delivered';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <PageNavigation 
        title="Track Your Shipment"
        subtitle="Enter your tracking ID to get real-time updates on your delivery"
      />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Tracking Form */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <form onSubmit={handleTrack} className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                placeholder="Enter Tracking ID (e.g., LGX-001-2024)"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center disabled:opacity-50"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <>
                  <Search className="h-5 w-5 mr-2" />
                  Track Shipment
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results */}
        {trackingId && !isLoading && shipment === null && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <Package className="h-12 w-12 text-red-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-red-800 mb-2">Shipment Not Found</h3>
            <p className="text-red-600">
              No shipment found with tracking ID: <span className="font-mono">{trackingId}</span>
            </p>
            <p className="text-sm text-red-500 mt-2">
              Please check your tracking ID and try again.
            </p>
          </div>
        )}

        {shipment && (
          <div className="space-y-8">
            {/* Status Overview */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Tracking ID: <span className="font-mono text-blue-600">{shipment.trackingId}</span>
                  </h2>
                  <div className="flex items-center space-x-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(shipment.status)}`}>
                      {getStatusText(shipment.status)}
                    </span>
                    <span className="text-gray-500">
                      Booked on {new Date(shipment.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                {shipment.estimatedDelivery && (
                  <div className="mt-4 lg:mt-0 text-right">
                    <div className="text-sm text-gray-500">Estimated Delivery</div>
                    <div className="text-lg font-semibold text-gray-900">
                      {new Date(shipment.estimatedDelivery).toLocaleDateString()} at {new Date(shipment.estimatedDelivery).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                )}
              </div>

              {/* Route Information */}
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-green-100 rounded-full">
                    <MapPin className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Pickup Location</div>
                    <div className="font-medium text-gray-900">{shipment.pickupLocation.address}</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-red-100 rounded-full">
                    <MapPin className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Delivery Location</div>
                    <div className="font-medium text-gray-900">{shipment.dropoffLocation.address}</div>
                  </div>
                </div>
              </div>

              {/* Load Information */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Shipment Details</h4>
                <div className="grid sm:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Load Type:</span>
                    <span className="ml-2 font-medium">{shipment.loadType}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Booking Mode:</span>
                    <span className="ml-2 font-medium capitalize">{shipment.bookingMode}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Price:</span>
                    <span className="ml-2 font-medium">₦{shipment.price.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Map View */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Live Location</h3>
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <div className="text-center">
                  <Navigation className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Interactive map would be displayed here</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Current location: {shipment.vehicle?.currentLocation?.address || 'Location updating...'}
                  </p>
                </div>
              </div>
            </div>

            {/* Driver & Vehicle Info */}
            {(shipment.driver || shipment.vehicle) && (
              <div className="grid md:grid-cols-2 gap-8">
                {/* Driver Info */}
                {shipment.driver && (
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <User className="h-5 w-5 mr-2" />
                      Driver Information
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Name:</span>
                        <span className="font-medium">{shipment.driver.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Phone:</span>
                        <a href={`tel:${shipment.driver.phone}`} className="font-medium text-blue-600 hover:underline">
                          {shipment.driver.phone}
                        </a>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Rating:</span>
                        <span className="font-medium">{shipment.driver.rating}/5 ⭐</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Status:</span>
                        <span className={`font-medium ${shipment.driver.status === 'on_trip' ? 'text-purple-600' : 'text-green-600'}`}>
                          {shipment.driver.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Vehicle Info */}
                {shipment.vehicle && (
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <Truck className="h-5 w-5 mr-2" />
                      Vehicle Information
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Plate Number:</span>
                        <span className="font-medium font-mono">{shipment.vehicle.plateNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Type:</span>
                        <span className="font-medium capitalize">{shipment.vehicle.type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Status:</span>
                        <span className={`font-medium ${
                          shipment.vehicle.status === 'in_transit' ? 'text-purple-600' : 
                          shipment.vehicle.status === 'available' ? 'text-green-600' : 'text-orange-600'
                        }`}>
                          {shipment.vehicle.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Sample Tracking IDs */}
        <div className="mt-12 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-medium text-blue-900 mb-3">Sample Tracking IDs for Demo:</h3>
          <div className="flex flex-wrap gap-2">
            {mockBookings.map(booking => (
              <button
                key={booking.trackingId}
                onClick={() => setTrackingId(booking.trackingId)}
                className="font-mono text-sm bg-white border border-blue-300 px-3 py-1 rounded hover:bg-blue-100 transition-colors"
              >
                {booking.trackingId}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}