import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Truck, 
  MapPin, 
  Clock, 
  Shield, 
  Smartphone, 
  BarChart3,
  CheckCircle,
  Star,
  ArrowRight
} from 'lucide-react';
import MovingVehicles from '../components/MovingVehicles';

export default function Landing() {
  const features = [
    {
      icon: Truck,
      title: 'Smart Booking',
      description: 'Book trucks online or offline with instant tracking ID generation'
    },
    {
      icon: MapPin,
      title: 'Real-Time Tracking',
      description: 'Monitor your shipments with GPS and SIM-based location updates'
    },
    {
      icon: Clock,
      title: '24/7 Operations',
      description: 'Round-the-clock logistics support across Africa'
    },
    {
      icon: Shield,
      title: 'Secure Transport',
      description: 'Verified drivers and vehicles with insurance coverage'
    },
    {
      icon: Smartphone,
      title: 'Mobile Optimized',
      description: 'Access from any device, anywhere, anytime'
    },
    {
      icon: BarChart3,
      title: 'Fleet Analytics',
      description: 'Comprehensive dashboard for fleet management and insights'
    }
  ];

  const testimonials = [
    {
      name: 'Adebayo Ogundimu',
      company: 'Lagos Import/Export Ltd',
      text: 'LogX has transformed our supply chain. Real-time tracking gives our customers confidence.',
      rating: 5
    },
    {
      name: 'Fatima Yusuf',
      company: 'Northern Trade Hub',
      text: 'The offline booking feature is perfect for remote areas. Game changer for African logistics.',
      rating: 5
    },
    {
      name: 'John Emeka',
      company: 'Cross-Border Logistics',
      text: 'Fleet management tools have improved our efficiency by 40%. Highly recommended.',
      rating: 5
    }
  ];

  return (
    <div className="space-y-0">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Revolutionizing African Logistics with 
              <span className="text-yellow-400"> Real-Time</span> Truck Booking
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-blue-100 max-w-3xl mx-auto">
              Connect shippers with verified truck drivers. Track shipments in real-time. 
              Manage fleets efficiently. Built for Africa, by logistics experts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/book"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center group"
              >
                Book a Truck
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/track"
                className="bg-white bg-opacity-10 hover:bg-opacity-20 backdrop-blur-sm border border-white border-opacity-30 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
              >
                Track Shipment
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Moving Vehicles Widget */}
      <MovingVehicles />

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose LogX?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Built specifically for the African logistics ecosystem with features that work both online and offline
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-xl hover:shadow-lg transition-shadow group hover-lift">
                <div className="p-3 bg-blue-100 rounded-lg w-fit mb-6 group-hover:bg-blue-200 transition-colors">
                  <feature.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Built for Shippers, By Logistics Experts
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                LogX was born from understanding the unique challenges of African logistics. 
                Our platform bridges the gap between traditional transportation methods and 
                modern technology, ensuring reliable deliveries across the continent.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <span className="text-gray-700">Verified drivers and vehicles across major African cities</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <span className="text-gray-700">Works online with GPS and offline with SIM tracking</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <span className="text-gray-700">Real-time notifications via SMS, WhatsApp, and email</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <span className="text-gray-700">Comprehensive fleet management and analytics</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-blue-600 rounded-2xl p-8 text-white">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold mb-2">500+</div>
                    <div className="text-blue-100">Verified Drivers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold mb-2">1000+</div>
                    <div className="text-blue-100">Active Vehicles</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold mb-2">50+</div>
                    <div className="text-blue-100">Cities Covered</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold mb-2">98%</div>
                    <div className="text-blue-100">On-Time Delivery</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Trusted by Businesses Across Africa
            </h2>
            <p className="text-xl text-gray-600">
              See what our customers say about LogX
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-xl hover-lift">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Transform Your Logistics?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of businesses already using LogX for reliable deliveries
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/book"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Start Shipping Today
            </Link>
            <Link
              to="/dashboard"
              className="bg-white bg-opacity-10 hover:bg-opacity-20 backdrop-blur-sm border border-white border-opacity-30 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Request Demo
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Truck className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold">LogX</span>
              </div>
              <p className="text-gray-400 mb-4">
                Revolutionizing African logistics with smart technology and reliable service.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/book" className="hover:text-white transition-colors">Book Truck</Link></li>
                <li><Link to="/track" className="hover:text-white transition-colors">Track Shipment</Link></li>
                <li><Link to="/dashboard" className="hover:text-white transition-colors">Fleet Management</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Live Chat</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="space-y-2 text-gray-400">
                <p>+234 800 LOGX (5649)</p>
                <p>support@logx.africa</p>
                <p>Lagos, Nigeria</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 LogX. All rights reserved. Built for Africa.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}