import React, { useState } from 'react';
import { MapPin, Navigation, Truck, User, Filter, Eye } from 'lucide-react';
import { mockVehicles, mockDrivers, mockTrips } from '../../data/mockData';

export default function FleetTracking() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'active' | 'available' | 'in_transit'>('all');
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);

  const getFilteredVehicles = () => {
    switch (selectedFilter) {
      case 'active':
        return mockVehicles.filter(v => v.status === 'available' || v.status === 'in_transit');
      case 'available':
        return mockVehicles.filter(v => v.status === 'available');
      case 'in_transit':
        return mockVehicles.filter(v => v.status === 'in_transit');
      default:
        return mockVehicles;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-500';
      case 'in_transit': return 'bg-purple-500';
      case 'maintenance': return 'bg-orange-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getDriverForVehicle = (vehicleId: string) => {
    return mockDrivers.find(d => d.vehicleId === vehicleId);
  };

  const getActiveTrip = (vehicleId: string) => {
    return mockTrips.find(t => t.vehicleId === vehicleId && t.status === 'active');
  };

  const filteredVehicles = getFilteredVehicles();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Fleet Tracking</h1>
        <p className="text-gray-600">Monitor all vehicles and drivers in real-time</p>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Filter by status:</span>
            <div className="flex space-x-2">
              {[
                { key: 'all', label: 'All', count: mockVehicles.length },
                { key: 'active', label: 'Active', count: mockVehicles.filter(v => v.status === 'available' || v.status === 'in_transit').length },
                { key: 'available', label: 'Available', count: mockVehicles.filter(v => v.status === 'available').length },
                { key: 'in_transit', label: 'In Transit', count: mockVehicles.filter(v => v.status === 'in_transit').length }
              ].map(filter => (
                <button
                  key={filter.key}
                  onClick={() => setSelectedFilter(filter.key as any)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === filter.key
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Map View */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Live Map View</h2>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Navigation className="h-4 w-4" />
                <span>Real-time tracking</span>
              </div>
            </div>
            
            <div className="bg-gray-100 rounded-lg h-96 flex items-center justify-center relative">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Interactive map would be displayed here</p>
                <p className="text-sm text-gray-500">
                  Showing {filteredVehicles.length} vehicles with real-time GPS tracking
                </p>
              </div>
              
              {/* Map Legend */}
              <div className="absolute top-4 right-4 bg-white rounded-lg p-3 shadow-sm">
                <h4 className="text-xs font-medium text-gray-700 mb-2">Vehicle Status</h4>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-xs text-gray-600">Available</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <span className="text-xs text-gray-600">In Transit</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <span className="text-xs text-gray-600">Maintenance</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                    <span className="text-xs text-gray-600">Offline</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle List */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">
              Vehicles ({filteredVehicles.length})
            </h2>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {filteredVehicles.map((vehicle) => {
              const driver = getDriverForVehicle(vehicle.id);
              const activeTrip = getActiveTrip(vehicle.id);
              
              return (
                <div
                  key={vehicle.id}
                  className={`p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors ${
                    selectedVehicle === vehicle.id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                  onClick={() => setSelectedVehicle(selectedVehicle === vehicle.id ? null : vehicle.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Truck className="h-6 w-6 text-gray-600" />
                        <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${getStatusColor(vehicle.status)}`}></div>
                      </div>
                      <div>
                        <div className="font-mono font-semibold text-gray-900">
                          {vehicle.plateNumber}
                        </div>
                        <div className="text-xs text-gray-500 capitalize">
                          {vehicle.type}
                        </div>
                      </div>
                    </div>
                    <button className="p-1 text-gray-400 hover:text-gray-600">
                      <Eye className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Status:</span>
                      <span className={`font-medium capitalize ${
                        vehicle.status === 'available' ? 'text-green-600' :
                        vehicle.status === 'in_transit' ? 'text-purple-600' :
                        vehicle.status === 'maintenance' ? 'text-orange-600' :
                        'text-gray-600'
                      }`}>
                        {vehicle.status.replace('_', ' ')}
                      </span>
                    </div>
                    
                    {driver && (
                      <div className="flex justify-between">
                        <span className="text-gray-500">Driver:</span>
                        <span className="font-medium text-gray-900">{driver.name}</span>
                      </div>
                    )}
                    
                    {vehicle.currentLocation && (
                      <div className="mt-2 pt-2 border-t border-gray-100">
                        <div className="flex items-start space-x-1">
                          <MapPin className="h-3 w-3 text-gray-400 mt-0.5" />
                          <span className="text-xs text-gray-600">
                            {vehicle.currentLocation.address}
                          </span>
                        </div>
                      </div>
                    )}
                    
                    {activeTrip && (
                      <div className="mt-2 pt-2 border-t border-gray-100">
                        <div className="text-xs text-purple-600 font-medium">
                          Active Trip: {activeTrip.bookingId}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="mt-8 grid sm:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="text-2xl font-bold text-green-600 mb-1">
            {mockVehicles.filter(v => v.status === 'available').length}
          </div>
          <div className="text-sm text-gray-600">Available Now</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="text-2xl font-bold text-purple-600 mb-1">
            {mockVehicles.filter(v => v.status === 'in_transit').length}
          </div>
          <div className="text-sm text-gray-600">On Active Trips</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-1">
            {mockDrivers.filter(d => d.status === 'active' || d.status === 'on_trip').length}
          </div>
          <div className="text-sm text-gray-600">Active Drivers</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="text-2xl font-bold text-gray-900 mb-1">
            {(mockDrivers.reduce((sum, d) => sum + d.rating, 0) / mockDrivers.length).toFixed(1)}
          </div>
          <div className="text-sm text-gray-600">Avg Driver Rating</div>
        </div>
      </div>
    </div>
  );
}