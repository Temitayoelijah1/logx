import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Truck, 
  Users, 
  Package, 
  BarChart3, 
  MapPin, 
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react';
import { mockVehicles, mockDrivers, mockBookings, mockTrips } from '../../data/mockData';
import PageNavigation from '../../components/Navigation/PageNavigation';

export default function FleetDashboard() {
  const activeVehicles = mockVehicles.filter(v => v.status === 'available' || v.status === 'in_transit').length;
  const activeDrivers = mockDrivers.filter(d => d.status === 'active' || d.status === 'on_trip').length;
  const activeTrips = mockTrips.filter(t => t.status === 'active').length;
  const pendingBookings = mockBookings.filter(b => b.status === 'pending').length;

  const stats = [
    {
      label: 'Active Vehicles',
      value: activeVehicles,
      total: mockVehicles.length,
      color: 'bg-blue-500',
      icon: Truck,
      link: '/dashboard/vehicles'
    },
    {
      label: 'Active Drivers',
      value: activeDrivers,
      total: mockDrivers.length,
      color: 'bg-green-500',
      icon: Users,
      link: '/dashboard/drivers'
    },
    {
      label: 'Active Trips',
      value: activeTrips,
      total: mockTrips.length,
      color: 'bg-purple-500',
      icon: MapPin,
      link: '/dashboard/tracking'
    },
    {
      label: 'Pending Assignments',
      value: pendingBookings,
      total: mockBookings.length,
      color: 'bg-orange-500',
      icon: Package,
      link: '/dashboard/assign-trips'
    }
  ];

  const quickActions = [
    {
      title: 'Assign Trips',
      description: 'Assign pending bookings to available drivers',
      icon: Package,
      color: 'bg-blue-600 hover:bg-blue-700',
      link: '/dashboard/assign-trips'
    },
    {
      title: 'Fleet Tracking',
      description: 'Monitor all vehicles in real-time',
      icon: MapPin,
      color: 'bg-green-600 hover:bg-green-700',
      link: '/dashboard/tracking'
    },
    {
      title: 'Add Vehicle',
      description: 'Register a new vehicle to the fleet',
      icon: Truck,
      color: 'bg-purple-600 hover:bg-purple-700',
      link: '/dashboard/vehicles'
    },
    {
      title: 'View Analytics',
      description: 'Check performance metrics and reports',
      icon: BarChart3,
      color: 'bg-orange-600 hover:bg-orange-700',
      link: '/dashboard/analytics'
    }
  ];

  const recentActivity = [
    {
      type: 'trip_completed',
      message: 'Trip LGX-001-2024 completed successfully',
      time: '2 minutes ago',
      icon: CheckCircle,
      color: 'text-green-600'
    },
    {
      type: 'driver_assigned',
      message: 'Emeka Johnson assigned to new booking',
      time: '15 minutes ago',
      icon: Users,
      color: 'text-blue-600'
    },
    {
      type: 'booking_pending',
      message: 'New booking requires driver assignment',
      time: '32 minutes ago',
      icon: AlertCircle,
      color: 'text-orange-600'
    },
    {
      type: 'vehicle_available',
      message: 'Vehicle LAG-123-AB is now available',
      time: '1 hour ago',
      icon: Truck,
      color: 'text-green-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PageNavigation 
        title="Fleet Dashboard"
        subtitle="Monitor and manage your fleet operations"
        showBreadcrumb={false}
      />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Link key={index} to={stat.link} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">of {stat.total}</p>
                </div>
              </div>
              <p className="text-sm text-gray-600">{stat.label}</p>
              <div className="mt-2 bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${stat.color}`}
                  style={{ width: `${(stat.value / stat.total) * 100}%` }}
                />
              </div>
            </Link>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {quickActions.map((action, index) => (
                  <Link
                    key={index}
                    to={action.link}
                    className={`${action.color} text-white p-6 rounded-lg transition-colors group`}
                  >
                    <div className="flex items-center space-x-3 mb-3">
                      <action.icon className="h-8 w-8" />
                      <h3 className="text-lg font-semibold">{action.title}</h3>
                    </div>
                    <p className="text-sm opacity-90">{action.description}</p>
                  </Link>
                ))}
              </div>
            </div>

            {/* Fleet Status Overview */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Fleet Status Overview</h2>
              
              <div className="space-y-6">
                {/* Vehicles Status */}
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-medium text-gray-900">Vehicles</h3>
                    <Link to="/dashboard/vehicles" className="text-blue-600 text-sm hover:underline">
                      View All
                    </Link>
                  </div>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {mockVehicles.filter(v => v.status === 'available').length}
                      </div>
                      <div className="text-xs text-green-700">Available</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {mockVehicles.filter(v => v.status === 'in_transit').length}
                      </div>
                      <div className="text-xs text-purple-700">In Transit</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {mockVehicles.filter(v => v.status === 'maintenance').length}
                      </div>
                      <div className="text-xs text-orange-700">Maintenance</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-600">
                        {mockVehicles.filter(v => v.status === 'offline').length}
                      </div>
                      <div className="text-xs text-gray-700">Offline</div>
                    </div>
                  </div>
                </div>

                {/* Drivers Status */}
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-medium text-gray-900">Drivers</h3>
                    <Link to="/dashboard/drivers" className="text-blue-600 text-sm hover:underline">
                      View All
                    </Link>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {mockDrivers.filter(d => d.status === 'active').length}
                      </div>
                      <div className="text-xs text-green-700">Active</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {mockDrivers.filter(d => d.status === 'on_trip').length}
                      </div>
                      <div className="text-xs text-purple-700">On Trip</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-600">
                        {mockDrivers.filter(d => d.status === 'offline').length}
                      </div>
                      <div className="text-xs text-gray-700">Offline</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
            
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className={`p-2 rounded-full bg-gray-100 ${activity.color}`}>
                    <activity.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>

            <Link
              to="/dashboard/activity"
              className="block text-center text-blue-600 text-sm font-medium mt-6 hover:underline"
            >
              View All Activity
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}