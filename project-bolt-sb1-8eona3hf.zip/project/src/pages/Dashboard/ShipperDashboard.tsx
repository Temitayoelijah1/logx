import React, { useState } from 'react';
import { Package, Clock, CheckCircle, XCircle, Plus, Eye, Phone } from 'lucide-react';
import { mockBookings } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import PageNavigation from '../../components/Navigation/PageNavigation';

export default function ShipperDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'current' | 'past' | 'all'>('current');

  // Filter bookings for current user
  const userBookings = mockBookings.filter(booking => booking.shipperId === user?.id);
  
  const currentBookings = userBookings.filter(b => ['pending', 'assigned', 'in_transit'].includes(b.status));
  const pastBookings = userBookings.filter(b => ['delivered', 'cancelled'].includes(b.status));

  const getBookings = () => {
    switch (activeTab) {
      case 'current': return currentBookings;
      case 'past': return pastBookings;
      case 'all': return userBookings;
      default: return currentBookings;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-orange-600 bg-orange-100';
      case 'assigned': return 'text-blue-600 bg-blue-100';
      case 'in_transit': return 'text-purple-600 bg-purple-100';
      case 'delivered': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return Clock;
      case 'assigned': return Package;
      case 'in_transit': return Package;
      case 'delivered': return CheckCircle;
      case 'cancelled': return XCircle;
      default: return Package;
    }
  };

  const stats = [
    {
      label: 'Active Shipments',
      value: currentBookings.length,
      color: 'bg-blue-500',
      icon: Package
    },
    {
      label: 'Completed',
      value: pastBookings.filter(b => b.status === 'delivered').length,
      color: 'bg-green-500',
      icon: CheckCircle
    },
    {
      label: 'Total Bookings',
      value: userBookings.length,
      color: 'bg-purple-500',
      icon: Package
    },
    {
      label: 'This Month',
      value: userBookings.filter(b => new Date(b.createdAt).getMonth() === new Date().getMonth()).length,
      color: 'bg-orange-500',
      icon: Clock
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PageNavigation 
        title={`Welcome back, ${user?.name}`}
        subtitle="Manage your shipments and track deliveries"
        showBreadcrumb={false}
      />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div className="flex-1">
            {/* This space is now handled by PageNavigation */}
          </div>
          <a
            href="/book"
            className="mt-4 sm:mt-0 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            New Booking
          </a>
        </div>

        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { key: 'current', label: 'Current Bookings', count: currentBookings.length },
                { key: 'past', label: 'Past Shipments', count: pastBookings.length },
                { key: 'all', label: 'All History', count: userBookings.length }
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.label} ({tab.count})
                </button>
              ))}
            </nav>
          </div>

          {/* Bookings List */}
          <div className="p-6">
            {getBookings().length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings found</h3>
                <p className="text-gray-600 mb-6">
                  {activeTab === 'current' 
                    ? "You don't have any active shipments" 
                    : "You haven't made any bookings yet"
                  }
                </p>
                <a
                  href="/book"
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Book Your First Truck
                </a>
              </div>
            ) : (
              <div className="space-y-4">
                {getBookings().map(booking => {
                  const StatusIcon = getStatusIcon(booking.status);
                  return (
                    <div key={booking.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            <span className="font-mono text-lg font-semibold text-blue-600">
                              {booking.trackingId}
                            </span>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center ${getStatusColor(booking.status)}`}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {booking.status.replace('_', ' ')}
                            </span>
                          </div>
                          
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <p className="text-sm text-gray-500">From:</p>
                              <p className="font-medium">{booking.pickupLocation.address}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">To:</p>
                              <p className="font-medium">{booking.dropoffLocation.address}</p>
                            </div>
                          </div>

                          <div className="grid sm:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Load Type:</span>
                              <span className="ml-1 font-medium">{booking.loadType}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Scheduled:</span>
                              <span className="ml-1 font-medium">
                                {new Date(booking.scheduledDate).toLocaleDateString()}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500">Price:</span>
                              <span className="ml-1 font-medium">₦{booking.price.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>

                        <div className="mt-4 lg:mt-0 lg:ml-6 flex flex-col sm:flex-row gap-2">
                          <a
                            href={`/track?id=${booking.trackingId}`}
                            className="bg-blue-100 text-blue-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-200 transition-colors flex items-center justify-center"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Track
                          </a>
                          {booking.status === 'in_transit' && (
                            <button className="bg-green-100 text-green-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-200 transition-colors flex items-center justify-center">
                              <Phone className="h-4 w-4 mr-1" />
                              Call Driver
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}