import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Download,
  Truck,
  Package,
  Clock,
  DollarSign
} from 'lucide-react';

export default function Analytics() {
  const [timeRange, setTimeRange] = useState<'daily' | 'weekly' | 'monthly'>('weekly');

  // Mock analytics data
  const metrics = {
    totalTrips: 156,
    completedTrips: 142,
    revenue: 2450000,
    avgDeliveryTime: 4.2,
    customerSatisfaction: 4.8,
    fleetUtilization: 78
  };

  const topDrivers = [
    { name: 'Emeka Johnson', trips: 23, rating: 4.9, revenue: 345000 },
    { name: 'Fatima Abdullahi', trips: 21, rating: 4.8, revenue: 315000 },
    { name: 'Chidi Okafor', trips: 19, rating: 4.7, revenue: 285000 },
    { name: 'Aisha Mohammed', trips: 18, rating: 4.6, revenue: 270000 },
    { name: 'Kemi Adebayo', trips: 16, rating: 4.5, revenue: 240000 }
  ];

  const recentTrends = [
    { metric: 'Trip Volume', change: '+12%', trend: 'up', color: 'text-green-600' },
    { metric: 'Revenue', change: '+8%', trend: 'up', color: 'text-green-600' },
    { metric: 'Delivery Time', change: '-5%', trend: 'down', color: 'text-green-600' },
    { metric: 'Fleet Utilization', change: '+15%', trend: 'up', color: 'text-green-600' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
          <p className="text-gray-600">Performance metrics and insights for your fleet</p>
        </div>
        
        <div className="flex items-center space-x-4 mt-4 sm:mt-0">
          <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
            {[
              { key: 'daily', label: 'Daily' },
              { key: 'weekly', label: 'Weekly' },
              { key: 'monthly', label: 'Monthly' }
            ].map(range => (
              <button
                key={range.key}
                onClick={() => setTimeRange(range.key as any)}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  timeRange === range.key
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
          
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Package className="h-5 w-5 text-blue-600" />
            </div>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{metrics.totalTrips}</div>
          <div className="text-sm text-gray-600">Total Trips</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-green-100 rounded-lg">
              <Package className="h-5 w-5 text-green-600" />
            </div>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{metrics.completedTrips}</div>
          <div className="text-sm text-gray-600">Completed</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-purple-100 rounded-lg">
              <DollarSign className="h-5 w-5 text-purple-600" />
            </div>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">₦{(metrics.revenue / 1000000).toFixed(1)}M</div>
          <div className="text-sm text-gray-600">Revenue</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Clock className="h-5 w-5 text-orange-600" />
            </div>
            <TrendingDown className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{metrics.avgDeliveryTime}h</div>
          <div className="text-sm text-gray-600">Avg Delivery</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <BarChart3 className="h-5 w-5 text-yellow-600" />
            </div>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{metrics.customerSatisfaction}</div>
          <div className="text-sm text-gray-600">Satisfaction</div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Truck className="h-5 w-5 text-indigo-600" />
            </div>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{metrics.fleetUtilization}%</div>
          <div className="text-sm text-gray-600">Utilization</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Charts Section */}
        <div className="lg:col-span-2 space-y-8">
          {/* Trip Volume Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Trip Volume Trends</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Calendar className="h-4 w-4" />
                <span>Last 30 days</span>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg h-64 flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Trip volume chart would be displayed here</p>
                <p className="text-sm text-gray-500 mt-2">
                  Showing daily trip counts and trends over time
                </p>
              </div>
            </div>
          </div>

          {/* Revenue Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Revenue Analysis</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <DollarSign className="h-4 w-4" />
                <span>Monthly breakdown</span>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg h-64 flex items-center justify-center">
              <div className="text-center">
                <TrendingUp className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Revenue chart would be displayed here</p>
                <p className="text-sm text-gray-500 mt-2">
                  Monthly revenue trends and projections
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-8">
          {/* Performance Trends */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h3>
            
            <div className="space-y-4">
              {recentTrends.map((trend, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{trend.metric}</span>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium ${trend.color}`}>
                      {trend.change}
                    </span>
                    {trend.trend === 'up' ? (
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-green-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Performing Drivers */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Drivers</h3>
            
            <div className="space-y-4">
              {topDrivers.map((driver, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{driver.name}</div>
                      <div className="text-xs text-gray-500">{driver.trips} trips</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      ₦{(driver.revenue / 1000).toFixed(0)}k
                    </div>
                    <div className="text-xs text-gray-500">⭐ {driver.rating}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            
            <div className="space-y-3">
              <button className="w-full bg-blue-50 text-blue-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors text-left">
                Generate Monthly Report
              </button>
              <button className="w-full bg-green-50 text-green-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-green-100 transition-colors text-left">
                Export Driver Performance
              </button>
              <button className="w-full bg-purple-50 text-purple-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-purple-100 transition-colors text-left">
                Download Revenue Report
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}