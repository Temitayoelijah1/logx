import React, { useState } from 'react';
import { Package, User, Truck, MapPin, Clock, CheckCircle } from 'lucide-react';
import { mockBookings, mockDrivers, mockVehicles } from '../../data/mockData';

export default function AssignTrips() {
  const [assignments, setAssignments] = useState<Record<string, { driverId: string; vehicleId: string }>>({});
  
  const pendingBookings = mockBookings.filter(b => b.status === 'pending');
  const availableDrivers = mockDrivers.filter(d => d.status === 'active');
  const availableVehicles = mockVehicles.filter(v => v.status === 'available');

  const handleAssign = (bookingId: string, driverId: string, vehicleId: string) => {
    setAssignments(prev => ({
      ...prev,
      [bookingId]: { driverId, vehicleId }
    }));
  };

  const handleConfirmAssignment = (bookingId: string) => {
    const assignment = assignments[bookingId];
    if (assignment) {
      // In a real app, this would make an API call
      console.log(`Assigning booking ${bookingId} to driver ${assignment.driverId} with vehicle ${assignment.vehicleId}`);
      
      // Remove from assignments after confirming
      setAssignments(prev => {
        const newAssignments = { ...prev };
        delete newAssignments[bookingId];
        return newAssignments;
      });
    }
  };

  const getDriverName = (driverId: string) => {
    return mockDrivers.find(d => d.id === driverId)?.name || 'Unknown Driver';
  };

  const getVehicleInfo = (vehicleId: string) => {
    const vehicle = mockVehicles.find(v => v.id === vehicleId);
    return vehicle ? `${vehicle.plateNumber} (${vehicle.type})` : 'Unknown Vehicle';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Assign Trips</h1>
        <p className="text-gray-600">Assign pending bookings to available drivers and vehicles</p>
      </div>

      {/* Summary Cards */}
      <div className="grid sm:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Pending Bookings</p>
              <p className="text-3xl font-bold text-orange-600">{pendingBookings.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-orange-500">
              <Package className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Available Drivers</p>
              <p className="text-3xl font-bold text-green-600">{availableDrivers.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <User className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Available Vehicles</p>
              <p className="text-3xl font-bold text-blue-600">{availableVehicles.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Truck className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Ready to Assign</p>
              <p className="text-3xl font-bold text-purple-600">{Object.keys(assignments).length}</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <CheckCircle className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {pendingBookings.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Pending Bookings</h3>
          <p className="text-gray-600">All bookings have been assigned to drivers.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Pending Trip Assignments</h2>
          </div>
          
          <div className="divide-y divide-gray-200">
            {pendingBookings.map((booking) => {
              const assignment = assignments[booking.id];
              const isAssigned = !!assignment;
              
              return (
                <div key={booking.id} className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                    {/* Booking Info */}
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <span className="font-mono text-lg font-semibold text-blue-600">
                          {booking.trackingId}
                        </span>
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-600">
                          Pending Assignment
                        </span>
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div className="flex items-start space-x-2">
                          <MapPin className="h-4 w-4 text-green-600 mt-1" />
                          <div>
                            <p className="text-sm text-gray-500">Pickup</p>
                            <p className="font-medium text-gray-900">{booking.pickupLocation.address}</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-2">
                          <MapPin className="h-4 w-4 text-red-600 mt-1" />
                          <div>
                            <p className="text-sm text-gray-500">Delivery</p>
                            <p className="font-medium text-gray-900">{booking.dropoffLocation.address}</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Load Type:</span>
                          <span className="ml-1 font-medium">{booking.loadType}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Scheduled:</span>
                          <span className="ml-1 font-medium">
                            {new Date(booking.scheduledDate).toLocaleDateString()}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Price:</span>
                          <span className="ml-1 font-medium">₦{booking.price.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Assignment Controls */}
                    <div className="lg:ml-8 lg:w-80">
                      {!isAssigned ? (
                        <div className="space-y-3">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Select Driver
                            </label>
                            <select
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              onChange={(e) => {
                                const driverId = e.target.value;
                                const currentAssignment = assignments[booking.id] || {};
                                if (driverId && currentAssignment.vehicleId) {
                                  handleAssign(booking.id, driverId, currentAssignment.vehicleId);
                                }
                              }}
                            >
                              <option value="">Choose a driver...</option>
                              {availableDrivers.map(driver => (
                                <option key={driver.id} value={driver.id}>
                                  {driver.name} - {driver.phone}
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Select Vehicle
                            </label>
                            <select
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              onChange={(e) => {
                                const vehicleId = e.target.value;
                                const currentAssignment = assignments[booking.id] || {};
                                if (vehicleId && currentAssignment.driverId) {
                                  handleAssign(booking.id, currentAssignment.driverId, vehicleId);
                                }
                              }}
                            >
                              <option value="">Choose a vehicle...</option>
                              {availableVehicles.map(vehicle => (
                                <option key={vehicle.id} value={vehicle.id}>
                                  {vehicle.plateNumber} - {vehicle.type}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                          <div className="flex items-center space-x-2 mb-3">
                            <CheckCircle className="h-5 w-5 text-green-600" />
                            <span className="font-medium text-green-800">Ready to Assign</span>
                          </div>
                          
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="text-gray-600">Driver:</span>
                              <span className="ml-1 font-medium">{getDriverName(assignment.driverId)}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Vehicle:</span>
                              <span className="ml-1 font-medium">{getVehicleInfo(assignment.vehicleId)}</span>
                            </div>
                          </div>
                          
                          <div className="flex gap-2 mt-4">
                            <button
                              onClick={() => handleConfirmAssignment(booking.id)}
                              className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                            >
                              Confirm Assignment
                            </button>
                            <button
                              onClick={() => setAssignments(prev => {
                                const newAssignments = { ...prev };
                                delete newAssignments[booking.id];
                                return newAssignments;
                              })}
                              className="px-4 py-2 text-gray-600 hover:text-gray-800 text-sm"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}