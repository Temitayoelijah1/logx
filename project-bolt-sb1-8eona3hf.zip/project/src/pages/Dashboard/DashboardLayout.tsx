import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Truck, 
  Users, 
  Package, 
  MapPin, 
  BarChart3,
  Settings,
  Activity
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function DashboardLayout() {
  const { user } = useAuth();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const shipperNavItems = [
    { path: '/dashboard', label: 'Overview', icon: LayoutDashboard },
    { path: '/dashboard/bookings', label: 'My Bookings', icon: Package },
    { path: '/dashboard/track', label: 'Track Shipments', icon: MapPin }
  ];

  const fleetNavItems = [
    { path: '/dashboard', label: 'Overview', icon: LayoutDashboard },
    { path: '/dashboard/vehicles', label: 'Manage Vehicles', icon: Truck },
    { path: '/dashboard/drivers', label: 'Manage Drivers', icon: Users },
    { path: '/dashboard/assign-trips', label: 'Assign Trips', icon: Package },
    { path: '/dashboard/tracking', label: 'Fleet Tracking', icon: MapPin },
    { path: '/dashboard/analytics', label: 'Analytics', icon: BarChart3 }
  ];

  const navItems = user?.role === 'fleet_admin' ? fleetNavItems : shipperNavItems;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r border-gray-200">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 capitalize">
            {user?.role?.replace('_', ' ')} Dashboard
          </h2>
        </div>
        
        <nav className="px-4 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                isActive(item.path)
                  ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                  : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <item.icon className={`mr-3 h-5 w-5 ${isActive(item.path) ? 'text-blue-700' : 'text-gray-400'}`} />
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="mt-8 px-4">
          <div className="border-t border-gray-200 pt-4">
            <Link
              to="/dashboard/settings"
              className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 hover:text-gray-900 transition-colors"
            >
              <Settings className="mr-3 h-5 w-5 text-gray-400" />
              Settings
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <Outlet />
      </div>
    </div>
  );
}