import React, { useState } from 'react';
import { MapPin, Calendar, Package, Truck, Smartphone, Wifi, Check } from 'lucide-react';
import PageNavigation from '../components/Navigation/PageNavigation';

export default function Booking() {
  const [bookingMode, setBookingMode] = useState<'online' | 'offline'>('online');
  const [formData, setFormData] = useState({
    pickupLocation: '',
    dropoffLocation: '',
    loadType: '',
    scheduledDate: '',
    scheduledTime: '',
    weight: '',
    description: ''
  });
  const [trackingId, setTrackingId] = useState('');
  const [isBooked, setIsBooked] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Generate tracking ID
    const newTrackingId = `LGX-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}-2024`;
    setTrackingId(newTrackingId);
    setIsBooked(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  if (isBooked) {
    return (
      <div className="min-h-screen bg-gray-50">
        <PageNavigation 
          title="Booking Confirmed"
          subtitle="Your truck booking has been successfully created"
          customBackPath="/book"
        />
        
        <div className="max-w-2xl mx-auto px-4 py-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="p-4 bg-green-100 rounded-full w-fit mx-auto mb-6">
              <Check className="h-12 w-12 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Booking Confirmed!</h1>
            <p className="text-lg text-gray-600 mb-8">
              Your truck booking has been successfully created.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Details</h3>
              <div className="space-y-3 text-left">
                <div className="flex justify-between">
                  <span className="text-gray-600">Tracking ID:</span>
                  <span className="font-mono font-semibold text-blue-600">{trackingId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Mode:</span>
                  <span className="capitalize">{bookingMode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className="text-orange-600 font-medium">
                    {bookingMode === 'online' ? 'Assigning Driver' : 'Pending Assignment'}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
              <p className="text-blue-800">
                <strong>Save your tracking ID:</strong> {trackingId}
              </p>
              <p className="text-sm text-blue-600 mt-2">
                You'll receive updates via SMS and email. You can track your shipment anytime using this ID.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => {
                  setIsBooked(false);
                  setTrackingId('');
                  setFormData({
                    pickupLocation: '',
                    dropoffLocation: '',
                    loadType: '',
                    scheduledDate: '',
                    scheduledTime: '',
                    weight: '',
                    description: ''
                  });
                }}
                className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Book Another Truck
              </button>
              <a
                href={`/track?id=${trackingId}`}
                className="flex-1 bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 transition-colors text-center"
              >
                Track This Shipment
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <PageNavigation 
        title="Book a Truck"
        subtitle="Schedule your shipment with verified drivers across Africa"
      />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Booking Mode Selection */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Booking Mode</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <button
              onClick={() => setBookingMode('online')}
              className={`p-6 rounded-lg border-2 transition-all ${
                bookingMode === 'online'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-center mb-3">
                <Wifi className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Online Booking</h3>
              <p className="text-sm text-gray-600">
                Real-time GPS tracking with instant driver assignment
              </p>
            </button>
            
            <button
              onClick={() => setBookingMode('offline')}
              className={`p-6 rounded-lg border-2 transition-all ${
                bookingMode === 'offline'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-center mb-3">
                <Smartphone className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Offline Booking</h3>
              <p className="text-sm text-gray-600">
                SIM-based tracking with manual driver assignment
              </p>
            </button>
          </div>
        </div>

        {/* Booking Form */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Pickup Location */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Pickup Location
                </label>
                <input
                  type="text"
                  name="pickupLocation"
                  value={formData.pickupLocation}
                  onChange={handleChange}
                  required
                  placeholder="Enter pickup address"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Dropoff Location */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Dropoff Location
                </label>
                <input
                  type="text"
                  name="dropoffLocation"
                  value={formData.dropoffLocation}
                  onChange={handleChange}
                  required
                  placeholder="Enter delivery address"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Load Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Package className="inline h-4 w-4 mr-1" />
                  Load Type
                </label>
                <select
                  name="loadType"
                  value={formData.loadType}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select load type</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Machinery">Machinery</option>
                  <option value="Food & Beverages">Food & Beverages</option>
                  <option value="Textiles">Textiles</option>
                  <option value="Construction Materials">Construction Materials</option>
                  <option value="Household Items">Household Items</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="inline h-4 w-4 mr-1" />
                  Pickup Date
                </label>
                <input
                  type="date"
                  name="scheduledDate"
                  value={formData.scheduledDate}
                  onChange={handleChange}
                  required
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Time */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pickup Time
                </label>
                <input
                  type="time"
                  name="scheduledTime"
                  value={formData.scheduledTime}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Weight */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Estimated Weight (kg)
              </label>
              <input
                type="number"
                name="weight"
                value={formData.weight}
                onChange={handleChange}
                placeholder="Enter approximate weight"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Details
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
                placeholder="Any special instructions or additional information..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Booking Mode Info */}
            <div className={`p-4 rounded-lg ${bookingMode === 'online' ? 'bg-blue-50 border border-blue-200' : 'bg-green-50 border border-green-200'}`}>
              <h4 className="font-medium mb-2">
                {bookingMode === 'online' ? 'Online Booking Benefits:' : 'Offline Booking Benefits:'}
              </h4>
              <ul className="text-sm space-y-1">
                {bookingMode === 'online' ? (
                  <>
                    <li>• Instant driver assignment and GPS tracking</li>
                    <li>• Real-time location updates</li>
                    <li>• Automatic notifications and alerts</li>
                  </>
                ) : (
                  <>
                    <li>• Works in areas with limited internet</li>
                    <li>• SIM-based location tracking</li>
                    <li>• Manual assignment by fleet administrators</li>
                  </>
                )}
              </ul>
            </div>

            {/* Submit Button */}
            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Truck className="h-5 w-5 mr-2" />
                Create Booking
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}