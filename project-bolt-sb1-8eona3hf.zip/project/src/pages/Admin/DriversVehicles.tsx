import React, { useState } from 'react';
import { 
  Truck, 
  User, 
  Search, 
  Filter, 
  Eye, 
  Edit, 
  CheckCircle, 
  XCircle,
  Phone,
  MapPin,
  Star,
  AlertTriangle,
  Plus
} from 'lucide-react';

export default function DriversVehicles() {
  const [activeTab, setActiveTab] = useState<'verified' | 'pending' | 'vehicles'>('verified');

  const verifiedDrivers = [
    { id: 'd1', name: 'Emeka Johnson', phone: '+234 803 123 4567', license: 'DL-12345678', vehicle: 'LAG-123-AB', status: 'Active', rating: 4.8, trips: 156 },
    { id: 'd2', name: 'Fatima Abdullahi', phone: '+234 806 987 6543', license: 'DL-87654321', vehicle: 'ABJ-456-CD', status: 'On Trip', rating: 4.9, trips: 142 },
    { id: 'd3', name: 'Chidi Okafor', phone: '+234 809 555 1234', license: 'DL-11223344', vehicle: 'KAN-789-EF', status: 'Offline', rating: 4.7, trips: 98 }
  ];

  const pendingDrivers = [
    { id: 'p1', name: 'Ahmed Musa', phone: '+234 805 111 2222', license: 'DL-99887766', documents: 'Pending Review', submitted: '2024-02-10' },
    { id: 'p2', name: 'Grace Adebayo', phone: '+234 807 333 4444', license: 'DL-55443322', documents: 'Incomplete', submitted: '2024-02-12' }
  ];

  const vehicles = [
    { id: 'v1', plateNumber: 'LAG-123-AB', type: 'Truck', owner: 'Lagos Express Fleet', driver: 'Emeka Johnson', status: 'Active', lastMaintenance: '2024-01-15' },
    { id: 'v2', plateNumber: 'ABJ-456-CD', type: 'Van', owner: 'Abuja Swift Delivery', driver: 'Fatima Abdullahi', status: 'In Transit', lastMaintenance: '2024-01-20' },
    { id: 'v3', plateNumber: 'KAN-789-EF', type: 'Truck', owner: 'Northern Transport Co', driver: 'Unassigned', status: 'Maintenance', lastMaintenance: '2024-02-01' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': case 'In Transit': return 'text-green-600 bg-green-100';
      case 'On Trip': return 'text-purple-600 bg-purple-100';
      case 'Offline': case 'Maintenance': return 'text-orange-600 bg-orange-100';
      case 'Pending Review': return 'text-blue-600 bg-blue-100';
      case 'Incomplete': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Drivers & Vehicles</h1>
          <p className="text-gray-600">Manage driver verification and vehicle registry</p>
        </div>
        <div className="flex space-x-3 mt-4 sm:mt-0">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors">
            Bulk Approve
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
            <Plus className="h-4 w-4 mr-2" />
            Add Vehicle
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Verified Drivers</p>
              <p className="text-3xl font-bold text-green-600">{verifiedDrivers.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <CheckCircle className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Pending Verification</p>
              <p className="text-3xl font-bold text-orange-600">{pendingDrivers.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-orange-500">
              <User className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active Vehicles</p>
              <p className="text-3xl font-bold text-blue-600">{vehicles.filter(v => v.status === 'Active' || v.status === 'In Transit').length}</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Truck className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Avg Driver Rating</p>
              <p className="text-3xl font-bold text-yellow-600">4.8</p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500">
              <Star className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search drivers, vehicles, or license numbers..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'verified', label: 'Verified Drivers', count: verifiedDrivers.length },
              { key: 'pending', label: 'Pending Drivers', count: pendingDrivers.length },
              { key: 'vehicles', label: 'Fleet Vehicles Registry', count: vehicles.length }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'verified' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vehicle</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {verifiedDrivers.map((driver) => (
                    <tr key={driver.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="p-2 bg-gray-100 rounded-full mr-3">
                            <User className="h-5 w-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{driver.name}</div>
                            <div className="text-sm text-gray-500 font-mono">{driver.license}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {driver.phone}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-mono">
                        {driver.vehicle}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(driver.status)}`}>
                          {driver.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-400" />
                          <span className="text-sm text-gray-900">{driver.rating}</span>
                          <span className="text-sm text-gray-500">({driver.trips} trips)</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <button className="text-blue-600 hover:text-blue-900 p-1" title="View Details">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="text-gray-600 hover:text-gray-900 p-1" title="Edit">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="text-green-600 hover:text-green-900 p-1" title="Call">
                          <Phone className="h-4 w-4" />
                        </button>
                        <button className="text-purple-600 hover:text-purple-900 p-1" title="Track">
                          <MapPin className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'pending' && (
            <div className="space-y-4">
              {pendingDrivers.map((driver) => (
                <div key={driver.id} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="p-2 bg-gray-100 rounded-full">
                          <User className="h-6 w-6 text-gray-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{driver.name}</h3>
                          <p className="text-sm text-gray-500">License: {driver.license}</p>
                        </div>
                      </div>
                      
                      <div className="grid sm:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Phone:</span>
                          <span className="ml-2 font-medium">{driver.phone}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Documents:</span>
                          <span className={`ml-2 font-medium ${driver.documents === 'Pending Review' ? 'text-blue-600' : 'text-red-600'}`}>
                            {driver.documents}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Submitted:</span>
                          <span className="ml-2 font-medium">{new Date(driver.submitted).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 lg:mt-0 lg:ml-6 flex flex-col sm:flex-row gap-2">
                      <button className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors flex items-center">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve
                      </button>
                      <button className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors flex items-center">
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject
                      </button>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center">
                        <Eye className="h-4 w-4 mr-1" />
                        Review
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'vehicles' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vehicle</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fleet Owner</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned Driver</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Maintenance</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {vehicles.map((vehicle) => (
                    <tr key={vehicle.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="p-2 bg-gray-100 rounded-full mr-3">
                            <Truck className="h-5 w-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900 font-mono">{vehicle.plateNumber}</div>
                            <div className="text-sm text-gray-500 capitalize">{vehicle.type}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {vehicle.owner}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {vehicle.driver}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(vehicle.status)}`}>
                          {vehicle.status === 'Maintenance' && <AlertTriangle className="h-3 w-3 mr-1" />}
                          {vehicle.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(vehicle.lastMaintenance).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <button className="text-blue-600 hover:text-blue-900 p-1" title="View Details">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="text-gray-600 hover:text-gray-900 p-1" title="Edit">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="text-purple-600 hover:text-purple-900 p-1" title="Track Location">
                          <MapPin className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}