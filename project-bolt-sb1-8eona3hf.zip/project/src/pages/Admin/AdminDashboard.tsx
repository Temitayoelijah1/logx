import React from 'react';
import { 
  BarChart3, 
  Users, 
  Truck, 
  Package, 
  AlertTriangle,
  TrendingUp,
  MapPin,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react';
import PageNavigation from '../../components/Navigation/PageNavigation';

export default function AdminDashboard() {
  const stats = [
    {
      title: 'Total Active Shipments',
      value: '154',
      change: '+12%',
      color: 'bg-blue-500',
      icon: Package
    },
    {
      title: 'Pending Driver Verifications',
      value: '12',
      change: '-5%',
      color: 'bg-orange-500',
      icon: Users
    },
    {
      title: 'Fleet Companies Onboarded',
      value: '41',
      change: '+8%',
      color: 'bg-green-500',
      icon: Truck
    },
    {
      title: 'Platform Alerts',
      value: '3',
      change: 'urgent',
      color: 'bg-red-500',
      icon: AlertTriangle
    }
  ];

  const topFleets = [
    { name: 'Lagos Express Logistics', onTime: '98%', trips: 234 },
    { name: 'Kano Transport Co.', onTime: '96%', trips: 189 },
    { name: 'Abuja Swift Delivery', onTime: '94%', trips: 156 },
    { name: 'Port Harcourt Freight', onTime: '92%', trips: 143 },
    { name: 'Ibadan Cargo Services', onTime: '90%', trips: 128 }
  ];

  const activeRoutes = [
    { route: 'Lagos → Abuja', trips: 45, status: 'High Traffic' },
    { route: 'Kano → Lagos', trips: 38, status: 'Normal' },
    { route: 'Port Harcourt → Lagos', trips: 32, status: 'Delayed' },
    { route: 'Ibadan → Abuja', trips: 28, status: 'Normal' },
    { route: 'Kaduna → Kano', trips: 24, status: 'Normal' }
  ];

  const recentAlerts = [
    { type: 'urgent', message: 'Driver verification backlog exceeding 48 hours', time: '5 min ago' },
    { type: 'warning', message: 'Fleet company "Northern Express" requires document update', time: '15 min ago' },
    { type: 'info', message: 'New dispute filed for Trip ID: LGX-234-2024', time: '32 min ago' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PageNavigation 
        title="Platform Overview"
        subtitle="Track real-time logistics activity across the platform"
        showBreadcrumb={false}
      />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className={`text-sm font-medium ${
                  stat.change.includes('+') ? 'text-green-600' : 
                  stat.change.includes('-') ? 'text-red-600' : 'text-orange-600'
                }`}>
                  {stat.change}
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.title}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Shipment Map Widget */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Live Shipment Map</h3>
              <div className="flex space-x-2">
                <button className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                  On Trip
                </button>
                <button className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-medium">
                  Idle
                </button>
                <button className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm font-medium">
                  Delayed
                </button>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg h-80 flex items-center justify-center relative">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Interactive map with real-time vehicle tracking</p>
                <p className="text-sm text-gray-500">
                  Showing 154 active shipments across Africa
                </p>
              </div>
              
              {/* Map Legend */}
              <div className="absolute top-4 right-4 bg-white rounded-lg p-3 shadow-sm border border-gray-200">
                <h4 className="text-xs font-medium text-gray-700 mb-2">Vehicle Status</h4>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-xs text-gray-600">On Trip (89)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                    <span className="text-xs text-gray-600">Idle (45)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <span className="text-xs text-gray-600">Delayed (20)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Side Panel */}
          <div className="space-y-6">
            {/* Platform Alerts */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Alerts</h3>
              <div className="space-y-3">
                {recentAlerts.map((alert, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className={`p-1 rounded-full ${
                      alert.type === 'urgent' ? 'bg-red-100' :
                      alert.type === 'warning' ? 'bg-orange-100' : 'bg-blue-100'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${
                        alert.type === 'urgent' ? 'bg-red-500' :
                        alert.type === 'warning' ? 'bg-orange-500' : 'bg-blue-500'
                      }`}></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900">{alert.message}</p>
                      <p className="text-xs text-gray-500">{alert.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full bg-blue-50 text-blue-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors text-left">
                  Verify Pending Drivers (12)
                </button>
                <button className="w-full bg-orange-50 text-orange-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-orange-100 transition-colors text-left">
                  Review Disputes (3)
                </button>
                <button className="w-full bg-green-50 text-green-700 px-4 py-3 rounded-lg text-sm font-medium hover:bg-green-100 transition-colors text-left">
                  Generate Weekly Report
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mt-8">
          {/* Top Performing Fleets */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Fleets</h3>
            <div className="space-y-4">
              {topFleets.map((fleet, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{fleet.name}</div>
                      <div className="text-xs text-gray-500">{fleet.trips} trips completed</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-600">{fleet.onTime}</div>
                    <div className="text-xs text-gray-500">on-time</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Most Active Routes */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Most Active Routes</h3>
            <div className="space-y-4">
              {activeRoutes.map((route, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-gray-900">{route.route}</div>
                    <div className="text-xs text-gray-500">{route.trips} active trips</div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    route.status === 'High Traffic' ? 'bg-orange-100 text-orange-700' :
                    route.status === 'Delayed' ? 'bg-red-100 text-red-700' :
                    'bg-green-100 text-green-700'
                  }`}>
                    {route.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Region-based Heatmap */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Regional Activity Heatmap</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-1">Lagos</div>
              <div className="text-sm text-gray-600">89 active shipments</div>
              <div className="text-xs text-green-600 mt-1">↑ 15% from last week</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-1">Abuja</div>
              <div className="text-sm text-gray-600">34 active shipments</div>
              <div className="text-xs text-green-600 mt-1">↑ 8% from last week</div>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-orange-600 mb-1">Kano</div>
              <div className="text-sm text-gray-600">21 active shipments</div>
              <div className="text-xs text-red-600 mt-1">↓ 3% from last week</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-1">Others</div>
              <div className="text-sm text-gray-600">10 active shipments</div>
              <div className="text-xs text-green-600 mt-1">↑ 5% from last week</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}