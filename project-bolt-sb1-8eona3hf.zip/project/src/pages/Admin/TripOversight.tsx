import React, { useState } from 'react';
import { 
  Package, 
  Search, 
  Filter, 
  Eye, 
  MapPin, 
  Clock, 
  AlertTriangle,
  Download,
  Flag,
  StopCircle,
  Navigation
} from 'lucide-react';

export default function TripOversight() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'active' | 'delayed' | 'completed'>('all');
  const [dateRange, setDateRange] = useState('today');

  const trips = [
    {
      id: 'LGX-001-2024',
      pickup: 'Ikeja Computer Village, Lagos',
      dropoff: 'Onitsha Main Market, Anambra',
      driver: 'Emeka Johnson',
      vehicle: 'LAG-123-AB',
      status: 'In Transit',
      eta: '2024-02-15T18:00:00Z',
      progress: 65,
      delay: null,
      shipper: 'TechMart Electronics',
      loadType: 'Electronics'
    },
    {
      id: 'LGX-002-2024',
      pickup: 'Apapa Port, Lagos',
      dropoff: 'Kano Industrial Area, Kano',
      driver: 'Fatima Abdullahi',
      vehicle: 'ABJ-456-CD',
      status: 'Delayed',
      eta: '2024-02-15T20:00:00Z',
      progress: 45,
      delay: '2 hours',
      shipper: 'Northern Industries',
      loadType: 'Machinery'
    },
    {
      id: 'LGX-003-2024',
      pickup: 'Alaba Market, Lagos',
      dropoff: 'Wuse Market, Abuja',
      driver: 'Chidi Okafor',
      vehicle: 'KAN-789-EF',
      status: 'Completed',
      eta: '2024-02-14T16:00:00Z',
      progress: 100,
      delay: null,
      shipper: 'Wholesale Distributors',
      loadType: 'Consumer Goods'
    },
    {
      id: 'LGX-004-2024',
      pickup: 'Port Harcourt Refinery',
      dropoff: 'Kaduna Depot',
      driver: 'Ahmed Musa',
      vehicle: 'PHC-111-XY',
      status: 'Active',
      eta: '2024-02-16T10:00:00Z',
      progress: 25,
      delay: null,
      shipper: 'Energy Solutions Ltd',
      loadType: 'Petroleum Products'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': case 'In Transit': return 'text-blue-600 bg-blue-100';
      case 'Delayed': return 'text-red-600 bg-red-100';
      case 'Completed': return 'text-green-600 bg-green-100';
      case 'Cancelled': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Active': case 'In Transit': return Navigation;
      case 'Delayed': return AlertTriangle;
      case 'Completed': return Package;
      default: return Package;
    }
  };

  const getFilteredTrips = () => {
    switch (selectedFilter) {
      case 'active':
        return trips.filter(t => t.status === 'Active' || t.status === 'In Transit');
      case 'delayed':
        return trips.filter(t => t.status === 'Delayed');
      case 'completed':
        return trips.filter(t => t.status === 'Completed');
      default:
        return trips;
    }
  };

  const filteredTrips = getFilteredTrips();

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Trip Oversight</h1>
          <p className="text-gray-600">Monitor and manage all trips across the platform</p>
        </div>
        <div className="flex space-x-3 mt-4 sm:mt-0">
          <button className="bg-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-700 transition-colors flex items-center">
            <Flag className="h-4 w-4 mr-2" />
            Flag Issues
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active Trips</p>
              <p className="text-3xl font-bold text-blue-600">
                {trips.filter(t => t.status === 'Active' || t.status === 'In Transit').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Navigation className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Delayed Trips</p>
              <p className="text-3xl font-bold text-red-600">
                {trips.filter(t => t.status === 'Delayed').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-red-500">
              <AlertTriangle className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Completed Today</p>
              <p className="text-3xl font-bold text-green-600">
                {trips.filter(t => t.status === 'Completed').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <Package className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">On-Time Rate</p>
              <p className="text-3xl font-bold text-purple-600">94%</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <Clock className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by trip ID, driver, or shipper..."
                className="pl-10 pr-4 py-2 w-full sm:w-80 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>
          
          <div className="flex space-x-2">
            {[
              { key: 'all', label: 'All', count: trips.length },
              { key: 'active', label: 'Active', count: trips.filter(t => t.status === 'Active' || t.status === 'In Transit').length },
              { key: 'delayed', label: 'Delayed', count: trips.filter(t => t.status === 'Delayed').length },
              { key: 'completed', label: 'Completed', count: trips.filter(t => t.status === 'Completed').length }
            ].map(filter => (
              <button
                key={filter.key}
                onClick={() => setSelectedFilter(filter.key as any)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                  selectedFilter === filter.key
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {filter.label} ({filter.count})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Trips Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            All Trips ({filteredTrips.length})
          </h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trip ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Route</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver & Vehicle</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Progress</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETA</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTrips.map((trip) => {
                const StatusIcon = getStatusIcon(trip.status);
                return (
                  <tr key={trip.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-blue-600 font-mono">{trip.id}</div>
                      <div className="text-sm text-gray-500">{trip.shipper}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">
                        <div className="flex items-center mb-1">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                          <span className="truncate max-w-xs">{trip.pickup}</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                          <span className="truncate max-w-xs">{trip.dropoff}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{trip.driver}</div>
                      <div className="text-sm text-gray-500 font-mono">{trip.vehicle}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(trip.status)}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {trip.status}
                      </span>
                      {trip.delay && (
                        <div className="text-xs text-red-600 mt-1">
                          {trip.delay} behind
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                          <div 
                            className={`h-2 rounded-full ${
                              trip.status === 'Delayed' ? 'bg-red-500' : 
                              trip.status === 'Completed' ? 'bg-green-500' : 'bg-blue-500'
                            }`}
                            style={{ width: `${trip.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600">{trip.progress}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {trip.status !== 'Completed' ? (
                        <div>
                          <div>{new Date(trip.eta).toLocaleDateString()}</div>
                          <div className="text-xs text-gray-500">
                            {new Date(trip.eta).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      ) : (
                        <span className="text-green-600 font-medium">Delivered</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                      <button className="text-blue-600 hover:text-blue-900 p-1" title="Track Live">
                        <MapPin className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-900 p-1" title="View Details">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-orange-600 hover:text-orange-900 p-1" title="Flag Issue">
                        <Flag className="h-4 w-4" />
                      </button>
                      {trip.status !== 'Completed' && (
                        <button className="text-red-600 hover:text-red-900 p-1" title="Force End">
                          <StopCircle className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Real-time Updates */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-blue-800 font-medium">Live Updates</span>
        </div>
        <p className="text-blue-700 text-sm mt-1">
          Trip LGX-001-2024 is currently 3 minutes behind schedule due to traffic conditions.
        </p>
      </div>
    </div>
  );
}