import React, { useState } from 'react';
import { 
  Building, 
  Search, 
  Filter, 
  Eye, 
  Edit, 
  Ban, 
  Plus,
  Truck,
  Users,
  Clock,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

export default function FleetCompanies() {
  const [searchTerm, setSearchTerm] = useState('');

  const fleetCompanies = [
    {
      id: 'fc1',
      name: 'Lagos Express Logistics',
      companyCode: 'LEL-001',
      vehicles: 45,
      drivers: 52,
      lastActivity: '2024-02-15T10:30:00Z',
      status: 'Active',
      onTimeDelivery: '98%',
      totalTrips: 1234,
      contact: {
        email: 'admin@lagosexpress.com',
        phone: '+234 803 123 4567',
        address: 'Victoria Island, Lagos'
      }
    },
    {
      id: 'fc2',
      name: 'Northern Transport Co.',
      companyCode: 'NTC-002',
      vehicles: 32,
      drivers: 38,
      lastActivity: '2024-02-14T15:45:00Z',
      status: 'Active',
      onTimeDelivery: '94%',
      totalTrips: 892,
      contact: {
        email: 'info@northerntransport.com',
        phone: '+234 806 987 6543',
        address: 'Kano, Nigeria'
      }
    },
    {
      id: 'fc3',
      name: 'Abuja Swift Delivery',
      companyCode: 'ASD-003',
      vehicles: 28,
      drivers: 31,
      lastActivity: '2024-02-13T09:20:00Z',
      status: 'Pending Update',
      onTimeDelivery: '92%',
      totalTrips: 567,
      contact: {
        email: 'contact@abujaswift.com',
        phone: '+234 809 555 1234',
        address: 'Abuja, FCT'
      }
    },
    {
      id: 'fc4',
      name: 'Port Harcourt Freight',
      companyCode: 'PHF-004',
      vehicles: 18,
      drivers: 22,
      lastActivity: '2024-02-10T14:15:00Z',
      status: 'Suspended',
      onTimeDelivery: '87%',
      totalTrips: 345,
      contact: {
        email: 'ops@phfreight.com',
        phone: '+234 807 333 4444',
        address: 'Port Harcourt, Rivers'
      }
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'text-green-600 bg-green-100';
      case 'Pending Update': return 'text-orange-600 bg-orange-100';
      case 'Suspended': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Active': return CheckCircle;
      case 'Pending Update': return Clock;
      case 'Suspended': return AlertTriangle;
      default: return Building;
    }
  };

  const filteredCompanies = fleetCompanies.filter(company =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.companyCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Fleet Company Directory</h1>
          <p className="text-gray-600">Manage registered fleet companies and their operations</p>
        </div>
        <button className="mt-4 sm:mt-0 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          Add New Fleet Company
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Companies</p>
              <p className="text-3xl font-bold text-blue-600">{fleetCompanies.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Building className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active Companies</p>
              <p className="text-3xl font-bold text-green-600">
                {fleetCompanies.filter(c => c.status === 'Active').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <CheckCircle className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Vehicles</p>
              <p className="text-3xl font-bold text-purple-600">
                {fleetCompanies.reduce((sum, c) => sum + c.vehicles, 0)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <Truck className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Drivers</p>
              <p className="text-3xl font-bold text-orange-600">
                {fleetCompanies.reduce((sum, c) => sum + c.drivers, 0)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-orange-500">
              <Users className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by company name or code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </button>
        </div>
      </div>

      {/* Fleet Companies Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Fleet Companies ({filteredCompanies.length})</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fleet Size</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Activity</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredCompanies.map((company) => {
                const StatusIcon = getStatusIcon(company.status);
                return (
                  <tr key={company.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="p-2 bg-gray-100 rounded-lg mr-3">
                          <Building className="h-6 w-6 text-gray-600" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{company.name}</div>
                          <div className="text-sm text-gray-500 font-mono">{company.companyCode}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            <Truck className="h-4 w-4 text-gray-400 mr-1" />
                            <span>{company.vehicles}</span>
                          </div>
                          <div className="flex items-center">
                            <Users className="h-4 w-4 text-gray-400 mr-1" />
                            <span>{company.drivers}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        <div className="font-medium text-green-600">{company.onTimeDelivery} on-time</div>
                        <div className="text-gray-500">{company.totalTrips} total trips</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(company.status)}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {company.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(company.lastActivity).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                      <button className="text-blue-600 hover:text-blue-900 p-1" title="View Profile">
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-900 p-1" title="Edit">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-orange-600 hover:text-orange-900 p-1" title="Request Update">
                        <Clock className="h-4 w-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900 p-1" title="Suspend">
                        <Ban className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Company Details Cards */}
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Companies</h3>
          <div className="space-y-4">
            {fleetCompanies
              .sort((a, b) => parseFloat(b.onTimeDelivery) - parseFloat(a.onTimeDelivery))
              .slice(0, 3)
              .map((company, index) => (
                <div key={company.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-900">{company.name}</div>
                      <div className="text-xs text-gray-500">{company.totalTrips} trips</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-600">{company.onTimeDelivery}</div>
                    <div className="text-xs text-gray-500">on-time delivery</div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fleet Distribution</h3>
          <div className="space-y-4">
            {fleetCompanies.map((company) => (
              <div key={company.id} className="flex items-center justify-between">
                <div className="text-sm font-medium text-gray-900">{company.name}</div>
                <div className="flex items-center space-x-2">
                  <div className="w-20 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${(company.vehicles / 50) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600">{company.vehicles}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}