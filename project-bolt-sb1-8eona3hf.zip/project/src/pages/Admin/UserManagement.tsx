import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  Eye, 
  Ban, 
  Trash2, 
  Edit,
  UserCheck,
  UserX,
  Building
} from 'lucide-react';

export default function UserManagement() {
  const [activeTab, setActiveTab] = useState<'shippers' | 'fleet_admins' | 'drivers' | 'blocked'>('shippers');
  const [searchTerm, setSearchTerm] = useState('');

  const users = {
    shippers: [
      { id: '1', name: 'Adebayo Ogundimu', email: 'adebayo@example.com', phone: '+234 803 123 4567', company: 'Lagos Import/Export Ltd', status: 'Active', joinedOn: '2024-01-15' },
      { id: '2', name: 'Fatima Yusuf', email: 'fatima@example.com', phone: '+234 806 987 6543', company: 'Northern Trade Hub', status: 'Active', joinedOn: '2024-01-20' },
      { id: '3', name: 'John Emeka', email: 'john@example.com', phone: '+234 809 555 1234', company: 'Cross-Border Logistics', status: 'Pending', joinedOn: '2024-02-01' }
    ],
    fleet_admins: [
      { id: '4', name: 'Sarah Fleet Manager', email: 'sarah@fleetco.com', phone: '+234 800 987 6543', company: 'Lagos Express Fleet', status: 'Active', joinedOn: '2024-01-10' },
      { id: '5', name: 'Ahmed Transport', email: 'ahmed@transport.com', phone: '+234 805 123 9876', company: 'Northern Transport Co', status: 'Active', joinedOn: '2024-01-25' }
    ],
    drivers: [
      { id: '6', name: 'Emeka Johnson', email: 'emeka@driver.com', phone: '+234 803 123 4567', company: 'Independent', status: 'Verified', joinedOn: '2024-01-12' },
      { id: '7', name: 'Fatima Abdullahi', email: 'fatima@driver.com', phone: '+234 806 987 6543', company: 'Lagos Express Fleet', status: 'Pending', joinedOn: '2024-02-05' }
    ],
    blocked: [
      { id: '8', name: 'Blocked User', email: 'blocked@example.com', phone: '+234 800 000 0000', company: 'N/A', status: 'Blocked', joinedOn: '2024-01-01' }
    ]
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': case 'Verified': return 'text-green-600 bg-green-100';
      case 'Pending': return 'text-orange-600 bg-orange-100';
      case 'Blocked': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTabIcon = (tab: string) => {
    switch (tab) {
      case 'shippers': return Users;
      case 'fleet_admins': return Building;
      case 'drivers': return UserCheck;
      case 'blocked': return UserX;
      default: return Users;
    }
  };

  const currentUsers = users[activeTab] || [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">User Management</h1>
          <p className="text-gray-600">Manage all platform users and their permissions</p>
        </div>
        <button className="mt-4 sm:mt-0 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center">
          <Users className="h-5 w-5 mr-2" />
          Add New User
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, or company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'shippers', label: 'Shippers', count: users.shippers.length },
              { key: 'fleet_admins', label: 'Fleet Admins', count: users.fleet_admins.length },
              { key: 'drivers', label: 'Drivers', count: users.drivers.length },
              { key: 'blocked', label: 'Blocked Accounts', count: users.blocked.length }
            ].map(tab => {
              const TabIcon = getTabIcon(tab.key);
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <TabIcon className="h-4 w-4 mr-2" />
                  {tab.label} ({tab.count})
                </button>
              );
            })}
          </nav>
        </div>

        {/* Users Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Joined On
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="p-2 bg-gray-100 rounded-full mr-3">
                        <Users className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{user.name}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {user.phone}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {user.company}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(user.status)}`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(user.joinedOn).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button className="text-blue-600 hover:text-blue-900 p-1" title="View Profile">
                      <Eye className="h-4 w-4" />
                    </button>
                    <button className="text-gray-600 hover:text-gray-900 p-1" title="Edit">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button className="text-orange-600 hover:text-orange-900 p-1" title="Suspend">
                      <Ban className="h-4 w-4" />
                    </button>
                    <button className="text-red-600 hover:text-red-900 p-1" title="Delete">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}