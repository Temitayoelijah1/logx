import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout/Layout';
import DashboardLayout from './pages/Dashboard/DashboardLayout';
import AdminLayout from './pages/Admin/AdminLayout';
import ProtectedRoute from './components/ProtectedRoute';

// Public Pages
import Landing from './pages/Landing';
import Booking from './pages/Booking';
import Tracking from './pages/Tracking';
import Login from './pages/Auth/Login';
import Signup from './pages/Auth/Signup';

// Dashboard Pages
import ShipperDashboard from './pages/Dashboard/ShipperDashboard';
import FleetDashboard from './pages/Dashboard/FleetDashboard';
import ManageVehicles from './pages/Dashboard/ManageVehicles';
import ManageDrivers from './pages/Dashboard/ManageDrivers';
import AssignTrips from './pages/Dashboard/AssignTrips';
import FleetTracking from './pages/Dashboard/FleetTracking';
import Analytics from './pages/Dashboard/Analytics';

// Admin Pages
import AdminDashboard from './pages/Admin/AdminDashboard';
import UserManagement from './pages/Admin/UserManagement';
import DriversVehicles from './pages/Admin/DriversVehicles';
import FleetCompanies from './pages/Admin/FleetCompanies';
import TripOversight from './pages/Admin/TripOversight';

function DashboardRouter() {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <Routes>
      <Route path="/" element={user.role === 'fleet_admin' ? <FleetDashboard /> : <ShipperDashboard />} />
      {user.role === 'fleet_admin' && (
        <>
          <Route path="/vehicles" element={<ManageVehicles />} />
          <Route path="/drivers" element={<ManageDrivers />} />
          <Route path="/assign-trips" element={<AssignTrips />} />
          <Route path="/tracking" element={<FleetTracking />} />
          <Route path="/analytics" element={<Analytics />} />
        </>
      )}
      {user.role === 'shipper' && (
        <>
          <Route path="/bookings" element={<ShipperDashboard />} />
          <Route path="/track" element={<Tracking />} />
        </>
      )}
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Layout />}>
            <Route index element={<Landing />} />
            <Route path="book" element={<Booking />} />
            <Route path="track" element={<Tracking />} />
          </Route>
          
          {/* Auth Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          
          {/* Protected Dashboard Routes */}
          <Route path="/dashboard/*" element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }>
            <Route path="*" element={<DashboardRouter />} />
          </Route>
          
          {/* Protected Admin Routes */}
          <Route path="/admin/*" element={
            <ProtectedRoute requiredRole="admin">
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<UserManagement />} />
            <Route path="drivers" element={<DriversVehicles />} />
            <Route path="fleets" element={<FleetCompanies />} />
            <Route path="trips" element={<TripOversight />} />
            <Route path="verification" element={<div>Verification Center - Coming Soon</div>} />
            <Route path="disputes" element={<div>Disputes - Coming Soon</div>} />
            <Route path="analytics" element={<div>Analytics & Reports - Coming Soon</div>} />
            <Route path="settings" element={<div>Platform Settings - Coming Soon</div>} />
            <Route path="security" element={<div>Access Logs & Security - Coming Soon</div>} />
          </Route>
          
          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;